package com.example.home_organization

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
