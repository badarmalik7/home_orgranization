import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Home Organization Assistant',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home Organization Assistant'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset('assets/images/1.jpg'),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TaskManagementScreen()),
                );
              },
              child: Text('Task Management'),
            ),
            SizedBox(height: 10), // Add a gap of 10 pixels between buttons
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ReminderSystemScreen()),
                );
              },
              child: Text('Reminder System'),
            ),
            SizedBox(height: 10), // Add a gap of 10 pixels between buttons
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TipsAndGuidesScreen()),
                );
              },
              child: Text('Tips and Guides'),
            ),
            SizedBox(height: 10), // Add a gap of 10 pixels between buttons
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => InventoryManagementScreen()),
                );
              },
              child: Text('Inventory Management'),
            ),
          ],
        ),
      ),
    );
  }
}

class TaskManagementScreen extends StatefulWidget {
  @override
  _TaskManagementScreenState createState() => _TaskManagementScreenState();
}

class _TaskManagementScreenState extends State<TaskManagementScreen> {
  final List<String> _tasks = [];
  final TextEditingController _taskController = TextEditingController();

  void _addTask(String task) {
    if (task.isNotEmpty) {
      setState(() {
        _tasks.add(task);
      });
      _taskController.clear();
    }
  }

  void _removeTask(int index) {
    setState(() {
      _tasks.removeAt(index);
    });
  }

  @override
  void dispose() {
    _taskController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Task Management'),
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(
                    'assets/images/6.jpg'), // Path to your background image
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: <Widget>[
                TextField(
                  controller: _taskController,
                  decoration: InputDecoration(
                    labelText: 'Enter a new task',
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.8),
                  ),
                  onSubmitted: _addTask,
                ),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () => _addTask(_taskController.text),
                  child: Text('Add Task'),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: _tasks.isEmpty
                      ? Center(
                          child: Text(
                            'No tasks yet, add a task to get started!',
                            style: TextStyle(color: Colors.white),
                          ),
                        )
                      : ListView.builder(
                          itemCount: _tasks.length,
                          itemBuilder: (context, index) {
                            return Card(
                              child: ListTile(
                                title: Text(_tasks[index]),
                                trailing: IconButton(
                                  icon: Icon(Icons.delete),
                                  onPressed: () => _removeTask(index),
                                ),
                              ),
                            );
                          },
                        ),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Back to Home'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ReminderSystemScreen extends StatefulWidget {
  @override
  _ReminderSystemScreenState createState() => _ReminderSystemScreenState();
}

class _ReminderSystemScreenState extends State<ReminderSystemScreen> {
  final List<Map<String, dynamic>> _reminders = [];
  final TextEditingController _taskController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();

  void _addReminder(String task, DateTime dateTime) {
    if (task.isNotEmpty && dateTime != null) {
      setState(() {
        _reminders.add({'task': task, 'dateTime': dateTime});
      });
      _taskController.clear();
      _dateController.clear();
    }
  }

  void _removeReminder(int index) {
    setState(() {
      _reminders.removeAt(index);
    });
  }

  @override
  void dispose() {
    _taskController.dispose();
    _dateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reminder System'),
      ),
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/3.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: <Widget>[
                TextField(
                  controller: _taskController,
                  decoration: InputDecoration(
                    labelText: 'Enter task',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: _dateController,
                  decoration: InputDecoration(
                    labelText: 'Enter date and time (yyyy-MM-dd HH:mm)',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.datetime,
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    String task = _taskController.text;
                    DateTime? dateTime =
                        DateTime.tryParse(_dateController.text);
                    if (dateTime != null) {
                      _addReminder(task, dateTime);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Reminder set for $task at $dateTime'),
                      ));
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text('Invalid date and time format'),
                      ));
                    }
                  },
                  child: Text('Set Reminder'),
                ),
                SizedBox(height: 20),
                Expanded(
                  child: _reminders.isEmpty
                      ? Center(child: Text('No reminders set.'))
                      : ListView.builder(
                          itemCount: _reminders.length,
                          itemBuilder: (context, index) {
                            final reminder = _reminders[index];
                            return Card(
                              child: ListTile(
                                title: Text(reminder['task']),
                                subtitle: Text(reminder['dateTime'].toString()),
                                trailing: IconButton(
                                  icon: Icon(Icons.delete),
                                  onPressed: () => _removeReminder(index),
                                ),
                              ),
                            );
                          },
                        ),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Back to Home'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TipsAndGuidesScreen extends StatelessWidget {
  final List<Map<String, String>> tipsAndGuides = [
    {
      'title': 'Start Small',
      'description':
          'Begin with a small area to avoid feeling overwhelmed. Tackle one drawer or one shelf at a time.'
    },
    {
      'title': 'Use Bins and Baskets',
      'description':
          'Bins and baskets are great for grouping similar items together, making them easier to find and keeping your space neat.'
    },
    {
      'title': 'Label Everything',
      'description':
          'Labels help everyone know where things belong and make it easier to put items away correctly.'
    },
    {
      'title': 'Donate or Dispose',
      'description':
          'Regularly go through your items and donate or dispose of things you no longer need or use.'
    },
    {
      'title': 'Create a Schedule',
      'description':
          'Set aside specific times for organization and decluttering to keep your home in order.'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tips and Guides'),
      ),
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/7.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: <Widget>[
                Text(
                  'Effective Organization and Decluttering Tips',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Expanded(
                  child: ListView.builder(
                    itemCount: tipsAndGuides.length,
                    itemBuilder: (context, index) {
                      final tip = tipsAndGuides[index];
                      return Card(
                        elevation: 5,
                        margin: EdgeInsets.symmetric(vertical: 8),
                        child: ListTile(
                          title: Text(
                            tip['title'] ?? 'No Title',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          subtitle:
                              Text(tip['description'] ?? 'No Description'),
                        ),
                      );
                    },
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Back to Home'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class InventoryManagementScreen extends StatelessWidget {
  final List<Map<String, String>> inventoryItems = [
    {
      'name': 'Milk',
      'quantity': '2 Liters',
      'image': 'assets/images/at.jpg',
    },
    {
      'name': 'Bread',
      'quantity': '1 Loaf',
      'image': 'assets/images/10.jpg',
    },
    {
      'name': 'Eggs',
      'quantity': '12 Pieces',
      'image': 'assets/images/9.jpg',
    },
    {
      'name': 'Rice',
      'quantity': '5 kg',
      'image': 'assets/images/11.jpg',
    },
    {
      'name': 'Apples',
      'quantity': '6 Pieces',
      'image': 'assets/images/12.jpg',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Inventory Management'),
      ),
      body: Stack(
        children: [
          // Background image
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/2.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: <Widget>[
                Text(
                  'Household Items, Groceries, and Supplies',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                Expanded(
                  child: ListView.builder(
                    itemCount: inventoryItems.length,
                    itemBuilder: (context, index) {
                      final item = inventoryItems[index];
                      return Card(
                        elevation: 5,
                        margin: EdgeInsets.symmetric(vertical: 8),
                        child: ListTile(
                          leading: Image.asset(
                            item['image'] ?? 'assets/placeholder.png',
                            width: 50,
                            height: 50,
                          ),
                          title: Text(
                            item['name'] ?? 'No Name',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(item['quantity'] ?? 'No Quantity'),
                        ),
                      );
                    },
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Back to Home'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
